---
title: {{ title }}
date: {{ date }}
updated: {{ date }}
layout: slide
slide:
  theme: white
  config:
    history: true
    mouseWheel: true
---
