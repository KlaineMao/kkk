---
title: 仿2048文字小游戏
tags:
  - JavaScript
  - 前端
  - 学习
categories:
  - 云游的小项目
date: 2017-03-04 23:33:23
updated: 2017-03-04 23:33:23
---

=。= 学习用 js 写了仿 2048 的小游戏

> [文字组合小游戏](http://calligraphy.yunyoujun.cn/combination/)

实际上早已年久失修，立个日后重写的 FLAG。

---

有空再分离出来把……
