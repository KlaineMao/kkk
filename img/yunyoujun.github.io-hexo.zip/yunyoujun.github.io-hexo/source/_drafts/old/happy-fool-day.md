---
title: 本站将停止一切更新
date: 2020-04-01 08:56:08
updated: 2020-04-01 08:56:08
tags:
categories:
type: bilibili
url: https://baike.baidu.com/item/%E6%84%9A%E4%BA%BA%E8%8A%82/114199
aplayer: true
---

{% meting "26830207" "netease" "song" "theme:#C20C0C"%}

对不起，再见了各位，我要前往二次元了。

![go-to-er-ci-yuan.jpg](https://i.loli.net/2020/04/01/8GNoYTAU2JbK75s.jpg)

<!-- more -->

---
