---
title: i-and-game
tags:
  - 随笔
categories:
  - 云游的小随笔
aplayer: true
---

{% meting "520459951" "netease" "song" "theme:#C20C0C" %}

## draft

我只希望，在未来的某一天，我可以指着某部电影或游戏结束的幕后制作人员，对别人说道：“看，这是我。”

我突然发现，我想做的事情并不是特定于游戏、动画、小说，我只是想做有趣的事情，有趣到花再多时间哪怕一生也不会后悔的事情。

就像森见登美彦一书当中，有趣即是正义。

让子弹飞

能赚钱 跪着

站着把钱赚了

<https://mp.weixin.qq.com/s/zQw3GBd0CSLkAiDpMXPD9A>

在大悲大欢之前，日常琐事早已显得无足轻重。
