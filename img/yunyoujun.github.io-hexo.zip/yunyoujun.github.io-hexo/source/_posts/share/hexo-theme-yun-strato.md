---
title: Strato - Hexo 主题「Yun」版本宣传 PV
date: 2020-08-28 22:00:00
updated: 2020-08-28 22:00:00
tags:
  - 分享
  - Hexo
  - 主题
categories:
  - 云游的小安利
type: bilibili
url: https://www.bilibili.com/video/BV17t4y1S7tz
---

为主题 [hexo-theme-yun](https://github.com/YunYouJun/hexo-theme-yun) v1.0 Strato 做的宣传 PV ～（~~也许是第一个有 PV 的 Hexo 主题？~~）

> 谢谢你喜欢我的主题！

当我第一次听说要做主题的宣传 PV 我是拒绝的，因为，不能你让我发 1.0，我就马上去发，第一我要试一下，因为我不愿意做完了以后再加一些特技上去，主题 Duang 一下，很亮、很柔，这样用户一定会骂我，根本没有这样的主题，就证明上面那个是假的。

后来我也不断在修 BUG，我自己用了大概一年左右，感觉还不错，后来我在做 PV 的时候也尽量不加特技，因为我要让用户看到，我用完之后是这个样子，你们用完之后也会是这个样子！

<!-- more -->
