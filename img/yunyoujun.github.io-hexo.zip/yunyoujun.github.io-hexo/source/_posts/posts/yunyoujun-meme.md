---
title: 云游君表情包制作计划
tags:
  - 云游君
  - 作品
  - 表情包
categories:
  - 云游的小画册
date: 2017-07-10 10:41:37
updated: 2017-07-10 10:41:37
---

> 大概算是自己人设的表情包制作吧。

<!-- more -->

![LOGO](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/logo/yun-logo.gif)

其实多数是仿照网上一些表情包的特色~~社会主义~~改造。（B 娘、蛆娘什么的）

嗯，有时间就画着玩儿。（~~大概~~）

![一脸懵逼](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/yunyoujun/daze.png)
![Orz](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/yunyoujun/orz.png)
![头像](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/yunyoujun/portrait.jpg)
![不明觉厉](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/yunyoujun/shuo-ren-hua-ba.jpg)
![是又怎么样](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/yunyoujun/yes-and-then.jpg)
![我怀疑你是单身狗](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/yunyoujun/you-are-a-single-dog.jpg)
![你对力量一无所知](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/yunyoujun/you-do-not-know-strength.jpg)
![云](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/yunyoujun/yun-logo.jpg)
