---
title: 水彩原创头像尝试
tags:
  - 作品
  - 瞎鸡儿画
categories:
  - 云游的小画册
date: 2017-07-12 21:15:06
updated: 2017-07-12 21:15:06
---

给朋友画的头像 _(:з」∠)_
基本是原创，上色参考了贴吧教程。
https://tieba.baidu.com/p/4735600472

颜色可能还是显得脏，=w=第一次尝试水彩风格加原创。（<del>自我满足感还是有的</del>）

![头像](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/duo-water.jpg)
