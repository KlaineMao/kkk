---
title: 临摹一只智障女神∠( ᐛ 」∠)＿
tags:
  - 作品
  - 瞎鸡儿画
categories:
  - 云游的小画册
date: 2017-08-25 15:05:26
updated: 2017-08-25 15:05:26
---

## Aqua

断断续续画了好久，一开始临摹时画的是黑白色，后来用了颜色模式图层，进行了魔改上色…（2333）

![阿库娅](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/konosuba-aqua.jpg)

<!-- more -->

## 原图

> ![原图](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/draw/rf/konosuba.png)
