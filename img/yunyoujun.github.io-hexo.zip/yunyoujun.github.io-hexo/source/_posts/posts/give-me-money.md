---
title: YunYouJun/give-me-money
date: 2017-12-26 18:22:28
updated: 2020-04-14 18:22:28
tags:
  - GitHub
  - 沙雕
  - 分享
categories:
  - 云游的小项目
type: github
url: https://github.com/YunYouJun/give-me-money
---

## [一个沙雕钓鱼网站](https://yunyoujun.cn/give-me-money/)

该项目**仅作娱乐**，博君一笑，您**无须填写任何相关真实信息**。
如果您不能理解笑点，不必强求。（网页声音预警，以防社会性死亡。）

---

这是自己几年前 Parcel 刚出的时候，写[「Parcel.js + Vue 搭建笔记」](https://yunyoujun.cn/note/vue-parcel-demo/)，拿来练手的小玩意儿。
所以代码很丑，也没做啥后端校验。 因为之前 API 次数被人恶意刷完了，所以重置了数据，现在加了邮箱验证才能提交。

大家乐呵乐呵完事了，我本身也是白嫖的 [LeanCloud](https://www.leancloud.cn/) 的开发版，刷数据最多也就到 LeanCloud 的每日上限。

如果你真的心动，并想要打钱，可以考虑捐给 [联合国儿童基金会](https://www.unicef.cn/)。

<!-- more -->
