---
title: 空调房
date: 2020-12-06 02:02:15
updated: 2020-12-06 17:46:15
reward: true
---

> 我们在此处安装了空调，您可以在此自由休憩。

---

<iframe style="width:100%;" height="760" frameborder="no" src="https://ac.yunyoujun.cn"></iframe>

---

裸机：<https://ac.yunyoujun.cn>
空调售后：[air-conditioner | GitHub](https://github.com/YunYouJun/air-conditioner)
前世今生：[云空调，便携小空调｜云游君的小站](https://www.yunyoujun.cn/posts/air-conditioner/)
