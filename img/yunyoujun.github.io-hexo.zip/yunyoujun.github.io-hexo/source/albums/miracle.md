---
title: 奇迹
date: 2020-04-18 16:27:24
updated: 2020-04-18 16:27:24
layout: gallery
photos:
  - caption: 我
    src: https://picsum.photos/800/600?random=1
    desc: 我想起那天夕阳下的奔跑
  - caption: 想起
    src: https://picsum.photos/800/600?random=2
    desc: 那是我逝去的青春
  - caption: 那天
    src: https://picsum.photos/800/600?random=3
    desc: 我们一日日度过的所谓日常
  - caption: 夕阳
    src: https://picsum.photos/800/600?random=4
    desc: 实际上可能是接连不断的奇迹
  - caption: 下
    src: https://picsum.photos/800/600?random=5
    desc: 错的不是我，是世界。
  - caption: 的
    src: https://picsum.photos/800/600?random=6
    desc: 是啊，我所爱的，即非群星，也非银河。
  - caption: 奔跑
    src: https://picsum.photos/800/600?random=7
    desc: 隐约雷鸣 阴霾天空 但盼风雨来 能留你在此
---
