---
layout: girls
title: Lovely Girls
date: 2019-01-07 11:17:35
updated: 2019-01-07 11:17:35
icon: icon-women-line
banner: <span title="我全都要！">大家都是我的天使！</span>
# - name:
#   avatar:
#   from:
#   url:
#   reason:
# https://github.com/YunYouJun/girls
# girls: https://cdn.jsdelivr.net/gh/YunYouJun/wives@gh-pages/girls.json
girls: https://wives.vercel.app/girls.json
random: true
---

![喜欢二次元这件事很恶心这一点我还是知道的](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/meme/love-er-ci-yuan-is-sick.jpg)
![爷就是二次元](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/meme/i-am-er-ci-yuan.jpg)
![她们是点阵、是数据、这种事情我知道。](https://cdn.jsdelivr.net/gh/YunYouJun/cdn/img/meme/i-like-paper-girls.jpg)

## 原则

- 可爱
- 拥有某种我喜爱的特质

![我对普通的人类没有兴趣](https://upyun.yunyoujun.cn/images/i-am-not-interested-in-ordinary-human.jpg)

> ~~我对普通的三次元女孩子没有兴趣。假如你们当中有纸片人、死宅、喜欢动漫或者一切有趣之事的女孩子，尽管来找我。完毕！~~

![不来的话就判你死刑](https://upyun.yunyoujun.cn/images/sentenced-to-death.jpg)
