---
title: 音乐
date: 2017-08-21 12:28:28
updated: 2017-08-21 12:28:28
tags:
  - 分享
categories:
  - 云游的小安利
aplayer: true
---

大概是看《夏洛特烦恼》时，最让自己感动到的歌吧。

{% meting "139377" "netease" "song" "theme:#C20C0C" %}

---

不知天高地厚时候的自己，也曾立志要改变世界吧。

{% meting "41664790" "netease" "song" "theme:#C20C0C" %}

---

像是一些已经忘却的回忆从脑海深处一点点渗了出来。

{% meting "407761576" "netease" "song" "theme:#C20C0C" %}

---

{% meting "557584656" "netease" "song" "theme:#C20C0C" %}

> 无限大な梦のあとの 在无限大的梦想后面
> 何もない世の中じゃ 这什么也没有的世界
> そうさ爱しい 亲爱的
> 想いも负けそうになるけど 即使我对你的思念比不上你
> Stay しがちなイメージだらけの 就算有一双满身停留影像的
> 頼りない翼でも 不可靠翅膀
> きっと飞べるさ 也一定能高飞的

---

让人充满希望

{% meting "28287132" "netease" "song" "theme:#C20C0C" %}

---

[バナナフィッシュの浜辺と黒い虹 with Aimer](https://music.163.com/#/song?id=29343309)

{% meting "29343309" "netease" "song" "theme:#C20C0C" %}

---

To Be Continued.
